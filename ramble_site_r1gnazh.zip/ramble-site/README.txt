RAMBLE — Check Center
Файлы: index.html и server-icon.png.

Публикация через GitHub Pages:
1. Создай репозиторий Public с именем ramble-check на https://github.com/
2. Add file → Upload files. Загрузи index.html и server-icon.png в корень репозитория.
3. Commit changes.
4. Settings → Pages → Deploy from a branch.
5. Выбери main и /(root), нажми Save.
6. После публикации GitHub покажет адрес вида https://ТВОЙ-ЛОГИН.github.io/ramble-check/

На странице есть подпись «Сделано R1gnazh» в самом верху.
Перед распространением проверь, что ссылка JournalTrace и нужная версия ShellBags Explorer соответствуют инструментам вашей команды.
